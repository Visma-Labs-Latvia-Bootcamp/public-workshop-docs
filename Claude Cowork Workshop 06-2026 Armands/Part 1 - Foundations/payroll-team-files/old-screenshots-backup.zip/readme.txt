Old screenshots backup - safe to delete. Fictional demo data.
